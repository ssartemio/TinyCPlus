/*
 * nghttp2 - HTTP/2 C Library
 *
 * Copyright (c) 2015 Tatsuhiro Tsujikawa
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
#ifndef SHRPX_SIGNAL_H
#define SHRPX_SIGNAL_H

#include "shrpx.h"

#include <signal.h>

#include <expected>

#include "errors.h"

using namespace nghttp2;

namespace shrpx {

inline constexpr int REOPEN_LOG_SIGNAL = SIGUSR1;
inline constexpr int EXEC_BINARY_SIGNAL = SIGUSR2;
inline constexpr int GRACEFUL_SHUTDOWN_SIGNAL = SIGQUIT;
inline constexpr int RELOAD_SIGNAL = SIGHUP;

// Blocks all signals and returns the previous signal mask.  The errno
// will indicate the error.
std::expected<sigset_t, Error> shrpx_signal_block_all();

// Unblocks all signals.  The errno will indicate the error.
std::expected<void, Error> shrpx_signal_unblock_all();

// Sets signal mask |set|.  The errno will indicate the error.
std::expected<void, Error> shrpx_signal_set(const sigset_t *set);

std::expected<void, Error> shrpx_signal_set_main_proc_ign_handler();
std::expected<void, Error> shrpx_signal_unset_main_proc_ign_handler();

std::expected<void, Error> shrpx_signal_set_worker_proc_ign_handler();
std::expected<void, Error> shrpx_signal_unset_worker_proc_ign_handler();

} // namespace shrpx

#endif // !defined(SHRPX_SIGNAL_H)
