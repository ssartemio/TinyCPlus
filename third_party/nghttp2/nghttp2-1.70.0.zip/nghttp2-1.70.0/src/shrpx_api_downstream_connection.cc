/*
 * nghttp2 - HTTP/2 C Library
 *
 * Copyright (c) 2016 Tatsuhiro Tsujikawa
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
#include "shrpx_api_downstream_connection.h"

#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <cstdlib>

#include "shrpx_client_handler.h"
#include "shrpx_upstream.h"
#include "shrpx_downstream.h"
#include "shrpx_worker.h"
#include "shrpx_connection_handler.h"
#include "shrpx_log.h"

namespace shrpx {

namespace {
const auto backendconfig_endpoint = APIEndpoint{
  "/api/v1beta1/backendconfig"sv,
  true,
  (1 << API_METHOD_POST) | (1 << API_METHOD_PUT),
  &APIDownstreamConnection::handle_backendconfig,
};

const auto configrevision_endpoint = APIEndpoint{
  "/api/v1beta1/configrevision"sv,
  true,
  (1 << API_METHOD_GET),
  &APIDownstreamConnection::handle_configrevision,
};
} // namespace

// The method string.  This must be same order of APIMethod.
constexpr std::string_view API_METHOD_STRING[] = {
  "GET"sv,
  "POST"sv,
  "PUT"sv,
};

APIDownstreamConnection::APIDownstreamConnection(Worker *worker)
  : worker_(worker) {}

APIDownstreamConnection::~APIDownstreamConnection() {
  if (fd_ != -1) {
    close(fd_);
  }
}

std::expected<void, Error>
APIDownstreamConnection::attach_downstream(Downstream *downstream) {
  if (log_enabled(INFO)) {
    Log{INFO, this} << "Attaching to DOWNSTREAM:" << downstream;
  }

  downstream_ = downstream;

  return {};
}

std::expected<void, Error>
APIDownstreamConnection::detach_downstream(Downstream *downstream) {
  if (log_enabled(INFO)) {
    Log{INFO, this} << "Detaching from DOWNSTREAM:" << downstream;
  }
  downstream_ = nullptr;

  return {};
}

std::expected<void, Error> APIDownstreamConnection::send_reply(
  unsigned int http_status, APIStatusCode api_status, std::string_view data) {
  shutdown_read_ = true;

  auto upstream = downstream_->get_upstream();

  auto &resp = downstream_->response();

  resp.http_status = http_status;

  auto &balloc = downstream_->get_block_allocator();

  std::string_view api_status_str;

  switch (api_status) {
  case APIStatusCode::SUCCESS:
    api_status_str = "Success"sv;
    break;
  case APIStatusCode::FAILURE:
    api_status_str = "Failure"sv;
    break;
  default:
    assert(0);
  }

  static constexpr auto M1 = "{\"status\":\""sv;
  static constexpr auto M2 = "\",\"code\":"sv;
  static constexpr auto M3 = "}"sv;

  // 3 is the number of digits in http_status, assuming it is 3 digits
  // number.
  auto buflen =
    M1.size() + M2.size() + M3.size() + data.size() + api_status_str.size() + 3;

  auto buf = make_byte_ref(balloc, buflen);
  auto p = std::ranges::begin(buf);

  p = std::ranges::copy(M1, p).out;
  p = std::ranges::copy(api_status_str, p).out;
  p = std::ranges::copy(M2, p).out;
  p = util::utos(http_status, p);
  p = std::ranges::copy(data, p).out;
  p = std::ranges::copy(M3, p).out;

  buf = buf.first(as_unsigned(p - std::ranges::begin(buf)));

  auto content_length = util::make_string_ref_uint(balloc, buf.size());

  resp.fs.add_header_token("content-length"sv, content_length, false,
                           http2::HD_CONTENT_LENGTH);

  switch (http_status) {
  case 400:
  case 405:
  case 413:
    resp.fs.add_header_token("connection"sv, "close"sv, false,
                             http2::HD_CONNECTION);
    break;
  }

  return upstream->send_reply(downstream_, buf);
}

namespace {
const APIEndpoint *lookup_api(std::string_view path) {
  switch (path.size()) {
  case 26:
    switch (path[25]) {
    case 'g':
      if (util::streq("/api/v1beta1/backendconfi"sv, path.substr(0, 25))) {
        return &backendconfig_endpoint;
      }
      break;
    }
    break;
  case 27:
    switch (path[26]) {
    case 'n':
      if (util::streq("/api/v1beta1/configrevisio"sv, path.substr(0, 26))) {
        return &configrevision_endpoint;
      }
      break;
    }
    break;
  }
  return nullptr;
}
} // namespace

std::expected<void, Error> APIDownstreamConnection::push_request_headers() {
  auto &req = downstream_->request();

  auto path = std::string_view{std::ranges::begin(req.path),
                               std::ranges::find(req.path, '?')};

  api_ = lookup_api(path);

  if (!api_) {
    return send_reply(404, APIStatusCode::FAILURE);
  }

  switch (req.method) {
  case HTTP_GET:
    if (!(api_->allowed_methods & (1 << API_METHOD_GET))) {
      return error_method_not_allowed();
    }
    break;
  case HTTP_POST:
    if (!(api_->allowed_methods & (1 << API_METHOD_POST))) {
      return error_method_not_allowed();
    }
    break;
  case HTTP_PUT:
    if (!(api_->allowed_methods & (1 << API_METHOD_PUT))) {
      return error_method_not_allowed();
    }
    break;
  default:
    return error_method_not_allowed();
  }

  // This works with req.fs.content_length == -1
  if (req.fs.content_length >
      static_cast<int64_t>(get_config()->api.max_request_body)) {
    return send_reply(413, APIStatusCode::FAILURE);
  }

  switch (req.method) {
  case HTTP_POST:
  case HTTP_PUT: {
    char tempname[] = "/tmp/nghttpx-api.XXXXXX";
#ifdef HAVE_MKOSTEMP
    fd_ = mkostemp(tempname, O_CLOEXEC);
#else  // !defined(HAVE_MKOSTEMP)
    fd_ = mkstemp(tempname);
#endif // !defined(HAVE_MKOSTEMP)
    if (fd_ == -1) {
      return send_reply(500, APIStatusCode::FAILURE);
    }
#ifndef HAVE_MKOSTEMP
    util::make_socket_closeonexec(fd_);
#endif // !defined(HAVE_MKOSTEMP)
    unlink(tempname);
    break;
  }
  }

  downstream_->set_request_header_sent(true);
  auto src = downstream_->get_blocked_request_buf();
  auto dest = downstream_->get_request_buf();
  src->remove(*dest);

  return {};
}

std::expected<void, Error> APIDownstreamConnection::error_method_not_allowed() {
  auto &resp = downstream_->response();

  size_t len = 0;
  for (uint8_t i = 0; i < API_METHOD_MAX; ++i) {
    if (api_->allowed_methods & (1 << i)) {
      // The length of method + ", "
      len += API_METHOD_STRING[i].size() + 2;
    }
  }

  assert(len > 0);

  auto &balloc = downstream_->get_block_allocator();

  auto iov = make_byte_ref(balloc, len + 1);
  auto p = std::ranges::begin(iov);
  for (uint8_t i = 0; i < API_METHOD_MAX; ++i) {
    if (api_->allowed_methods & (1 << i)) {
      auto &s = API_METHOD_STRING[i];
      p = std::ranges::copy(s, p).out;
      p = std::ranges::copy(", "sv, p).out;
    }
  }

  p -= 2;
  *p = '\0';

  resp.fs.add_header_token(
    "allow"sv, as_string_view(std::ranges::begin(iov), p), false, -1);
  return send_reply(405, APIStatusCode::FAILURE);
}

std::expected<void, Error>
APIDownstreamConnection::push_upload_data_chunk(std::span<const uint8_t> data) {
  if (shutdown_read_ || !api_->require_body) {
    return {};
  }

  auto &req = downstream_->request();
  auto &apiconf = get_config()->api;

  if (static_cast<size_t>(req.recv_body_length) > apiconf.max_request_body) {
    return send_reply(413, APIStatusCode::FAILURE);
  }

  ssize_t nwrite;

  for (; !data.empty();) {
    while ((nwrite = write(fd_, data.data(), data.size())) == -1 &&
           errno == EINTR)
      ;
    if (nwrite == -1) {
      auto error = errno;
      Log{ERROR} << "Could not write API request body: errno=" << error;
      return send_reply(500, APIStatusCode::FAILURE);
    }

    data = data.subspan(as_unsigned(nwrite));
  }

  // We don't have to call Upstream::resume_read() here, because
  // request buffer is effectively unlimited.  Actually, we cannot
  // call it here since it could recursively call this function again.

  return {};
}

std::expected<void, Error> APIDownstreamConnection::end_upload_data() {
  if (shutdown_read_) {
    return {};
  }

  return api_->handler(*this);
}

std::expected<void, Error> APIDownstreamConnection::handle_backendconfig() {
  auto &req = downstream_->request();

  if (req.recv_body_length == 0) {
    return send_reply(200, APIStatusCode::SUCCESS);
  }

  auto rp = mmap(nullptr, static_cast<size_t>(req.recv_body_length), PROT_READ,
                 MAP_SHARED, fd_, 0);
  if (rp == reinterpret_cast<void *>(-1)) {
    return send_reply(500, APIStatusCode::FAILURE);
  }

  auto unmapper = defer([rp, size = req.recv_body_length] {
    munmap(rp, static_cast<size_t>(size));
  });

  Config new_config{};
  new_config.conn.downstream = std::make_shared<DownstreamConfig>();
  const auto &downstreamconf = new_config.conn.downstream;

  auto config = get_config();
  auto &src = config->conn.downstream;

  downstreamconf->timeout = src->timeout;
  downstreamconf->connections_per_host = src->connections_per_host;
  downstreamconf->connections_per_frontend = src->connections_per_frontend;
  downstreamconf->request_buffer_size = src->request_buffer_size;
  downstreamconf->response_buffer_size = src->response_buffer_size;
  downstreamconf->family = src->family;

  std::unordered_set<std::string_view> include_set;
  std::unordered_map<std::string_view, size_t> pattern_addr_indexer;

  for (auto first = reinterpret_cast<const char *>(rp),
            last = first + req.recv_body_length;
       first != last;) {
    auto eol = std::ranges::find(first, last, '\n');
    if (eol == last) {
      break;
    }

    if (first == eol || *first == '#') {
      first = ++eol;
      continue;
    }

    auto eq = std::ranges::find(first, eol, '=');
    if (eq == eol) {
      return send_reply(400, APIStatusCode::FAILURE);
    }

    auto opt = std::string_view{first, eq};
    auto optval = std::string_view{eq + 1, eol};

    auto optid = option_lookup_token(opt);

    switch (optid) {
    case SHRPX_OPTID_BACKEND:
      break;
    default:
      first = ++eol;
      continue;
    }

    if (auto rv = parse_config(&new_config, optid, opt, optval, include_set,
                               pattern_addr_indexer);
        !rv) {
      return send_reply(400, APIStatusCode::FAILURE);
    }

    first = ++eol;
  }

  auto &tlsconf = config->tls;
  if (auto rv = configure_downstream_group(&new_config, config->http2_proxy,
                                           true, tlsconf);
      !rv) {
    return send_reply(400, APIStatusCode::FAILURE);
  }

  auto conn_handler = worker_->get_connection_handler();

  conn_handler->send_replace_downstream(downstreamconf);

  return send_reply(200, APIStatusCode::SUCCESS);
}

std::expected<void, Error> APIDownstreamConnection::handle_configrevision() {
  auto config = get_config();
  auto &balloc = downstream_->get_block_allocator();

  // Construct the following string:
  //   ,
  //   "data":{
  //     "configRevision": N
  //   }
  auto data = concat_string_ref(
    balloc, R"(,"data":{"configRevision":)"sv,
    util::make_string_ref_uint(balloc, config->config_revision), "}"sv);

  return send_reply(200, APIStatusCode::SUCCESS, data);
}

void APIDownstreamConnection::pause_read(IOCtrlReason reason) {}

void APIDownstreamConnection::force_resume_read() {}

void APIDownstreamConnection::on_upstream_change(Upstream *upstream) {}

bool APIDownstreamConnection::poolable() const { return false; }

const std::shared_ptr<DownstreamAddrGroup> &
APIDownstreamConnection::get_downstream_addr_group() const {
  static std::shared_ptr<DownstreamAddrGroup> s;
  return s;
}

DownstreamAddr *APIDownstreamConnection::get_addr() const { return nullptr; }

} // namespace shrpx
